<?php

	/**
	 * fonts must be .ttf files, put in appropriate folder in /css/fonts/{fontname}/{fontname}-{variation}.ttf. File name must be lowercase
	 */
	$madara_fonts = array();
	/**
	 * default Google Fonts used
	 * for example: $madara_google_fonts = ["Source Code Pro: 400,500,600"]
	 */
	$madara_google_fonts = [];