<?php

	/**
	 * Url Helper
	 */

	namespace App\Helpers;

	class URL {
		public function __contstruct() {

		}
	}