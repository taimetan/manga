<?php

	/**
	 * Class General
	 *
	 * @package madara
	 */

	namespace App\Models\Entity;

	use App\Models;

	class General extends Models\Metadata {
		public function __construct() {

		}
	}
