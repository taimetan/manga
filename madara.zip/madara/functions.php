<?php
	/**
	 * Madara Functions and Definitions
	 *
	 * @package madara
	 */
	require( get_template_directory() . '/app/theme.php' );
    update_site_option( 'madara_supported_until','01.01.2030' );
	update_site_option( 'madara_purchase_code' ,'gpllicense');
	update_site_option( 'madara_activated', 'yes' );