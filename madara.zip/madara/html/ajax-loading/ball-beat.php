<?php
	/*
	*
	* ball-beat
	*
	*/
?>
<div class="loader-inner ball-beat">
    <div></div>
    <div></div>
    <div></div>
</div>