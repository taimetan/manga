<?php
	/*
	*
	* ball-clip-rotate-pulse
	*
	*/
?>
<div class="loader-inner ball-clip-rotate-pulse">
    <div></div>
    <div></div>
</div>