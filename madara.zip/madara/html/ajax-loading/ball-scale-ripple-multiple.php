<?php
	/*
	*
	* ball-scale-ripple-multiple
	*
	*/
?>
<div class="loader-inner ball-scale-ripple-multiple">
    <div></div>
    <div></div>
    <div></div>
</div>