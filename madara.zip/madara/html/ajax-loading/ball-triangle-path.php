<?php
	/*
	*
	* ball-triangle-path
	*
	*/
?>
<div class="loader-inner ball-triangle-path">
    <div></div>
    <div></div>
    <div></div>
</div>