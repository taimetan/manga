<?php
	/*
	*
	* cube-transition
	*
	*/
?>
<div class="loader-inner cube-transition">
    <div></div>
    <div></div>
</div>