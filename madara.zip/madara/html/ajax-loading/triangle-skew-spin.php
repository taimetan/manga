<?php
	/*
	*
	* triangle-skew-spin
	*
	*/
?>
<div class="loader-inner triangle-skew-spin">
    <div></div>
</div>