<?php if ( has_post_thumbnail() ) { ?>
    <div class="summary_image">
        <a href="<?php echo get_the_permalink(); ?>">
            <?php echo madara_thumbnail( 'full' ); ?>
        </a>
    </div>
<?php } ?>
<div class="summary_content_wrap">
    <div class="summary_content">
        <div class="post-content">
            <?php get_template_part( 'html/ajax-loading/ball-pulse' ); ?>
            
            <?php do_action('wp-manga-manga-properties', get_the_ID());?>
            
            <?php do_action('wp-manga-after-manga-properties', get_the_ID());?>
            
            <div class="post-status">
        
                <?php do_action('wp-manga-manga-status', get_the_ID());?>

            </div>
            
            <?php if ( get_the_content() != '' ) {
                ?>
            <div class="manga-excerpt">            
                <?php 
                global $post;
                echo wp_kses_post($post->post_content);
                ?>
            </div>
            <?php } ?>
            
            <?php
            $is_oneshot = is_manga_oneshot($post_id);
    
            if(!$is_oneshot){
                set_query_var( 'manga_id', $post_id );
                get_template_part('madara-core/single/quick-buttons');
            }
            ?>
        </div>        
    </div>
</div>