<?php

$madara = \App\Madara::getInstance();
$setting = $madara->getOption('manga_single_tags_post', 'info');
if($tags != '' && ($setting == 'info' || $setting == 'both')) {?>
<div class="post-content_item">
	<div class="summary-heading">
		<h5>
			<?php echo esc_html__( 'Tag(s)', 'madara' ); ?>
		</h5>
	</div>
	<div class="summary-content">
		<div class="tags-content">
			<?php echo wp_kses_post( $tags ); ?>
		</div>
	</div>
</div>

<?php }