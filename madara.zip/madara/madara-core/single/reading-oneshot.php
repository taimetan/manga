<?php

use App\Madara;

// get first chapter of this oneshort manga
global $wp_manga_functions;

$post_id = get_the_ID();
$chapters = $wp_manga_functions->get_latest_chapters($post_id, false, 1);

if($chapters){
    $chapter = $chapters[0];
    
    // trick to tell others that this is a reading chapter
    set_query_var('chapter', $chapter['chapter_slug']);
    
    // need a full data chapter object
    $chapter  = $wp_manga_functions->get_single_chapter( $post_id, $chapter['chapter_id'] );
    
    $in_use   = $chapter['storage']['inUse'];
	$alt_host = isset( $_GET['host'] ) ? $_GET['host'] : null;
	if ( $alt_host ) {
		$in_use = $alt_host;
	}
	
	$storage = $chapter['storage'];
	if ( ! isset( $storage[ $in_use ] ) || ! is_array( $storage[ $in_use ]['page'] ) ) {
		return;
	}

	$madara_reading_list_total_item = 0;
    
    $is_lazy_load = Madara::getOption( 'lazyload', 'off' ) == 'on' ? true : false;
	if ( $is_lazy_load ) {
		$lazyload = 'wp-manga-chapter-img img-responsive lazyload effect-fade';
	} else {
		$lazyload = 'wp-manga-chapter-img';
	}
	
	$need_button_fullsize = false;
    
    $lazyload_dfimg = apply_filters( 'madara_image_placeholder_url', get_parent_theme_file_uri( '/images/dflazy.jpg' ), 0 );
?>
<div id="oneshot-reader">
    <div class="row">        
        <?php
        $i = 0;
        $total_page = count($chapter['storage'][ $in_use ]['page']);
        
        foreach ( $chapter['storage'][ $in_use ]['page'] as $page => $link ) {

            $madara_reading_list_total_item = count( $chapter['storage'][ $in_use ]['page'] );

            $host = $chapter['storage'][ $in_use ]['host'];
            $src  = apply_filters('wp_manga_chapter_image_url', $host . $link['src'], $host, $link['src'], $post_id, $name);
            
            if($src != ''){
            $i++;
            ?>

            <?php do_action( 'madara_before_chapter_image_wrapper', $page, $madara_reading_list_total_item ); ?>
            <div class="col-lg-2 col-md-3 col-6">
                <div class="image-item">

                    <?php do_action( 'madara_before_chapter_image', $page, $madara_reading_list_total_item );
                    ?>
                    <a href="<?php echo esc_url( $src ); ?>" data-lightbox="chapter-images">
                    <img id="image-<?php echo esc_attr( $page ); ?>" src="<?php echo esc_url($lazyload_dfimg);?>" <?php if($is_lazy_load){ echo 'data-src="'; } else { echo 'src="';}?><?php echo esc_url( $src ); ?>" class="<?php echo esc_attr( $lazyload ); ?>">
                    </a>
                    <?php 
                    
                    do_action( 'madara_after_chapter_image', $page, $madara_reading_list_total_item ); ?>
                </div>
                <?php do_action( 'madara_after_chapter_image_wrapper', $page, $madara_reading_list_total_item ); ?>
            </div>
            <?php   
                if($i%6 == 0 || $i == $total_page){
                    // end of 1 row
                    ?>
    </div>
                    <?php
                    if($i < $total_page){
                        // open new row
                        ?>
    <div class="row">
                        <?php
                    }
                }
                
            }
        }
    ?>
</div>
    <?php
}
?>