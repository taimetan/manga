<div id="main-sidebar" class="main-sidebar woo-sidebar" role="complementary">
    <?php
			dynamic_sidebar('woo_sidebar');
	?>
</div>